<?php
/**
 * Created by PhpStorm.
 * User: denisov
 * Date: 01.10.2017
 * Time: 12:24
 */

namespace common\models;

use Da\User\Model\User as BaseUser;

class User extends BaseUser
{

}