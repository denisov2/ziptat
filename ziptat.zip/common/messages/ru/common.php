<?php
/**
 * Created by PhpStorm.
 * User: denisov
 * Date: 27.09.2017
 * Time: 11:02
 */

return [

    /*************************** ЯЗЫКИ ***************/

    'Русский' => 'Русский',
    'English' => 'English',

    /********* Пункты меню в админке ************/


    'Menu' => 'Меню',

    'Labels' => 'Наклейки',
    'Labels Categories' => 'Категории наклеек',
    'Labels Subcategories' => 'Подкатегории наклеек',


    'Users' => 'Пользователи',
    'Order' => 'Заказы',

    'News' => 'Новости',
    'Articles' => 'Статьи',
    'Pages' => 'Статические страницы',

    'Image editor' => 'Редактор изображений',
    'Top Menu' => 'Верхнее Меню',
    'Referral program' => 'Реферальная программа',
    'Mailing lists' => 'Email рассылка',
    'Html Blocks (Widgets)' => 'Html блоки (Виджеты)',
    'Site Options' => 'Настройки сайта',


];